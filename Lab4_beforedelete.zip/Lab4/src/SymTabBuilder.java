
import node.*;
import symboltable.*;
import cpparser.analysis.DepthFirstAdapter;

import analysis.*;

public class SymTabBuilder extends DepthFirstAdapter
{ 
    static private SymbolTable symtab = new SymbolTable();

    public SymTabBuilder(){
//    	topLevel 
    }
    
    public SymbolTable symtab() {
	return symtab;
    }
    
    //  your evaluation rules (i.e., method overrides) go here.
    

}
/*        end of SymTabBuilder       */










