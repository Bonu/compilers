#/bin/sh!
java  -classpath /Users/jbonu/git/compilers/Documents/sablecc-3.6/lib/sablecc.jar org.sablecc.sablecc.SableCC /Users/jbonu/git/compilers/Lab4/src/CP_Parser.scc