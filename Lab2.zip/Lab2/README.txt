ISSUE 1
Verifying identifiers.
java.lang.RuntimeException: [0,0] Redefinition of AClassDecls.

ISSUE 2





References:
http://sablecc.sourceforge.net/thesis/thesis.html#PAGE45

https://groups.google.com/forum/#!topic/comp.compilers/JUga-QcnmLI



