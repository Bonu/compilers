LAb 3 - Symbol Table

The lookup1, lookup2 and enclosing_method  is not working. Remaining other features are working withou any issue.

