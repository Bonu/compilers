Lab 4 - Symbol Table Builder

The test cases in01, in02, in03, in04, in05 are working, but the output is not appropriate.
The test cases in06, in07, in08 are failed

